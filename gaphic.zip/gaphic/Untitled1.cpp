
#include<math.h>

#include<conio.h>

#include<iostream>

#include <graphics.h>

int main(){

 initwindow(800,600);

 float x=0,y=0;

 line(0,300,getmaxx(),300); //x line axis

 line(400,0,400,getmaxy()); //y line axis

 float time=0.001;

 for(int i=0;i<95;i++){

  x=x+(time*i);

  y=i;

  putpixel (x,y,WHITE);

 }

 getch();

 closegraph();

 return 0;

 

}
